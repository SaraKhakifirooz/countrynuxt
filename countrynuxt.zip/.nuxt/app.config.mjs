
import { defuFn } from 'E:/SaraKhaki/javiddddd/countrynuxt/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
